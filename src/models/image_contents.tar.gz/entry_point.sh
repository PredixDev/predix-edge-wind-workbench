#!/bin/sh
echo "Setting time zone to '${TIME_ZONE}'"

cp /usr/share/zoneinfo/${TIME_ZONE} /etc/localtime
echo "${TIME_ZONE}" >/etc/timezone

cd /opt/microservice
exec python app_code.py
